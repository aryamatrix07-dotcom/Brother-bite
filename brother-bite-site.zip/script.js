/* =========================================================
   Brother Bite: script.js
   Modules: config, utils, smooth scroll, intro, hero,
   scene (WebGL particles), food3d (scroll-driven 3D food),
   cursor, magnetic, spotlight, progress, animations,
   palette, faq, form, init
   ========================================================= */
(function () {
  "use strict";

  /* ---------------- CONFIG (client edits here) ---------------- */
  const CONFIG = {
    brandName: "Brother Bite",
    particles: { high: 2200, low: 1200 },
    colorA: "#f2a541",
    colorB: "#e4572e",
    introSeenKey: "bb-intro-seen",
    formEndpoint: "https://example.com/subscribe", // TODO: replace with your real form endpoint
  };

  /* ---------------- Utilities ---------------- */
  const hasGSAP = typeof window.gsap !== "undefined";
  const hasScrollTrigger = typeof window.ScrollTrigger !== "undefined";
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  const finePointer = window.matchMedia("(hover: hover) and (pointer: fine)");

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const lerp = (a, b, t) => a + (b - a) * t;
  const clamp = (v, min, max) => Math.min(max, Math.max(min, v));
  const debounce = (fn, wait) => {
    let t = 0;
    return (...args) => {
      clearTimeout(t);
      t = setTimeout(() => fn(...args), wait);
    };
  };

  let lenis = null;
  let menuBtn = null;
  let menuEl = null;

  /* ---------------- Smooth scroll (Lenis + GSAP ticker) ---------------- */
  function initSmoothScroll() {
    if (!window.Lenis || reduceMotion.matches) return;
    lenis = new window.Lenis({ duration: 1.2, smoothWheel: true });

    if (hasGSAP && hasScrollTrigger) {
      lenis.on("scroll", ScrollTrigger.update);
      gsap.ticker.add((time) => lenis.raf(time * 1000));
      gsap.ticker.lagSmoothing(0);
    } else {
      const raf = (time) => {
        lenis.raf(time);
        requestAnimationFrame(raf);
      };
      requestAnimationFrame(raf);
    }
  }

  function scrollToTarget(target) {
    if (!target) return;
    if (lenis) lenis.scrollTo(target, { offset: -80 });
    else target.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function initAnchors() {
    document.addEventListener("click", (e) => {
      const link = e.target.closest("a[data-scroll]");
      if (!link) return;
      const href = link.getAttribute("href");
      const target = href && href.startsWith("#") ? document.getElementById(href.slice(1)) : null;
      if (!target) return;
      e.preventDefault();
      closeMenu();
      scrollToTarget(target);
    });
  }

  /* ---------------- Intro overlay ---------------- */
  function playIntro(onDone) {
    const intro = $("#intro");
    let seen = false;
    try {
      seen = sessionStorage.getItem(CONFIG.introSeenKey) === "1";
    } catch (_) {
      seen = false;
    }

    if (!intro || seen || reduceMotion.matches || !hasGSAP) {
      if (intro) intro.remove();
      onDone();
      return;
    }

    try {
      sessionStorage.setItem(CONFIG.introSeenKey, "1");
    } catch (_) { /* storage unavailable: intro simply replays */ }

    const tl = gsap.timeline({
      onComplete: () => {
        intro.remove();
        onDone();
      },
    });
    tl.fromTo(
      ".intro-mark",
      { scale: 0.6, opacity: 0, filter: "blur(12px)" },
      { scale: 1, opacity: 1, filter: "blur(0px)", duration: 0.8, ease: "power3.out" }
    ).to(".intro", { yPercent: -100, duration: 0.9, ease: "power4.inOut", delay: 0.3 });
  }

  /* ---------------- Hero text ---------------- */
  function splitHeroWords() {
    $$("[data-split]").forEach((el) => {
      const words = el.textContent.trim().split(/\s+/);
      el.textContent = "";
      words.forEach((word, i) => {
        const wrap = document.createElement("span");
        wrap.className = "word-wrap";
        const inner = document.createElement("span");
        inner.className = "word";
        inner.textContent = word;
        wrap.appendChild(inner);
        el.appendChild(wrap);
        if (i < words.length - 1) el.appendChild(document.createTextNode(" "));
      });
    });
  }

  function animateHero() {
    if (!hasGSAP || reduceMotion.matches) return;
    const tl = gsap.timeline({ defaults: { ease: "power4.out" } });
    tl.from(".hero-title .word", { yPercent: 110, duration: 1, stagger: 0.07 })
      .from(".hero-eyebrow, .hero-sub, .hero-ctas, .stat", { y: 20, opacity: 0, duration: 0.9, stagger: 0.1 }, "-=0.7")
      .from(".scroll-hint", { opacity: 0, duration: 1 }, "-=0.4");
  }

  /* ---------------- 3D scene (WebGL particle field) ---------------- */
  const VERTEX_SHADER = /* glsl */ `
    uniform float uTime;
    uniform vec2 uMouse;
    uniform float uPixelRatio;
    attribute float aScale;
    attribute float aSeed;
    varying float vAlpha;
    varying float vSeed;

    void main() {
      vec3 p = position;

      float n = sin(p.x * 1.3 + uTime * 0.6 + aSeed * 6.2831)
              * cos(p.y * 1.1 - uTime * 0.5)
              + sin(p.z * 1.7 + uTime * 0.4);
      p += normalize(p) * n * 0.12;

      vec2 m = uMouse * 2.6;
      float d = distance(p.xy, m);
      float infl = smoothstep(1.4, 0.0, d);
      p.xy += normalize(p.xy - m + 0.0001) * infl * 0.35;

      vec4 mv = modelViewMatrix * vec4(p, 1.0);
      gl_Position = projectionMatrix * mv;
      gl_PointSize = aScale * uPixelRatio * (70.0 / -mv.z);

      vAlpha = 0.35 + infl * 0.65;
      vSeed = aSeed;
    }
  `;

  const FRAGMENT_SHADER = /* glsl */ `
    uniform vec3 uColorA;
    uniform vec3 uColorB;
    varying float vAlpha;
    varying float vSeed;

    void main() {
      float d = length(gl_PointCoord - 0.5);
      if (d > 0.5) discard;
      float a = smoothstep(0.5, 0.0, d) * vAlpha;
      vec3 col = mix(uColorA, uColorB, vSeed);
      gl_FragColor = vec4(col, a);
    }
  `;

  const Scene = (() => {
    const lowEnd =
      (navigator.hardwareConcurrency || 4) <= 4 || (navigator.deviceMemory || 8) <= 4;
    const target = { x: 0, y: 0 };
    const smooth = { x: 0, y: 0 };

    let container = null;
    let renderer = null;
    let scene = null;
    let camera = null;
    let points = null;
    let core = null;
    let uniforms = null;
    let clock = null;
    let rafId = 0;
    let running = false;
    let inView = true;

    function buildGeometry(count) {
      const pos = new Float32Array(count * 3);
      const scale = new Float32Array(count);
      const seed = new Float32Array(count);

      for (let i = 0; i < count; i++) {
        const u = Math.random() * 2 - 1;
        const t = Math.random() * Math.PI * 2;
        const s = Math.sqrt(1 - u * u);
        const r = 1.6 + Math.random() * 1.8;

        pos[i * 3] = r * s * Math.cos(t);
        pos[i * 3 + 1] = r * s * Math.sin(t);
        pos[i * 3 + 2] = r * u;
        scale[i] = 0.6 + Math.random() * 1.6;
        seed[i] = Math.random();
      }

      const geometry = new THREE.BufferGeometry();
      geometry.setAttribute("position", new THREE.BufferAttribute(pos, 3));
      geometry.setAttribute("aScale", new THREE.BufferAttribute(scale, 1));
      geometry.setAttribute("aSeed", new THREE.BufferAttribute(seed, 1));
      return geometry;
    }

    function step(dt) {
      uniforms.uTime.value += dt;
      smooth.x = lerp(smooth.x, target.x, 0.06);
      smooth.y = lerp(smooth.y, target.y, 0.06);
      uniforms.uMouse.value.set(smooth.x, smooth.y);

      points.rotation.y += dt * 0.06;
      points.rotation.x = lerp(points.rotation.x, smooth.y * 0.25, 0.04);
      core.rotation.x += dt * 0.2;
      core.rotation.y += dt * 0.3;
    }

    function render() {
      renderer.render(scene, camera);
    }

    function tick() {
      if (!running) return;
      rafId = requestAnimationFrame(tick);
      step(Math.min(clock.getDelta(), 0.05));
      render();
    }

    function shouldRun() {
      return inView && !document.hidden && !reduceMotion.matches;
    }

    function syncLoop() {
      if (!renderer) return;
      if (shouldRun()) {
        if (!running) {
          running = true;
          clock.getDelta();
          rafId = requestAnimationFrame(tick);
        }
      } else if (running) {
        running = false;
        cancelAnimationFrame(rafId);
      }
    }

    function resize() {
      if (!renderer) return;
      const rect = container.getBoundingClientRect();
      const width = Math.max(1, rect.width);
      const height = Math.max(1, rect.height);
      renderer.setSize(width, height, false);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      uniforms.uPixelRatio.value = renderer.getPixelRatio();
      if (!running) render();
    }

    function init(el) {
      container = el;
      if (!container) return;
      if (typeof window.THREE === "undefined") {
        container.classList.add("is-fallback");
        return;
      }

      try {
        renderer = new THREE.WebGLRenderer({
          antialias: false,
          alpha: true,
          powerPreference: "high-performance",
        });
      } catch (_) {
        container.classList.add("is-fallback");
        return;
      }

      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
      renderer.domElement.setAttribute("aria-hidden", "true");
      container.appendChild(renderer.domElement);

      scene = new THREE.Scene();
      camera = new THREE.PerspectiveCamera(50, 1, 0.1, 100);
      camera.position.z = 6;
      clock = new THREE.Clock();

      uniforms = {
        uTime: { value: 0 },
        uMouse: { value: new THREE.Vector2() },
        uPixelRatio: { value: renderer.getPixelRatio() },
        uColorA: { value: new THREE.Color(CONFIG.colorA) },
        uColorB: { value: new THREE.Color(CONFIG.colorB) },
      };

      const material = new THREE.ShaderMaterial({
        vertexShader: VERTEX_SHADER,
        fragmentShader: FRAGMENT_SHADER,
        uniforms,
        transparent: true,
        depthWrite: false,
        blending: THREE.NormalBlending,
      });

      const count = lowEnd ? CONFIG.particles.low : CONFIG.particles.high;
      points = new THREE.Points(buildGeometry(count), material);

      core = new THREE.Mesh(
        new THREE.IcosahedronGeometry(0.9, 1),
        new THREE.MeshBasicMaterial({ color: CONFIG.colorA, wireframe: true, transparent: true, opacity: 0.18 })
      );
      const orb = new THREE.Mesh(
        new THREE.SphereGeometry(0.32, 32, 32),
        new THREE.MeshBasicMaterial({ color: CONFIG.colorB, transparent: true, opacity: 0.55 })
      );

      scene.add(points, core, orb);

      window.addEventListener(
        "pointermove",
        (e) => {
          target.x = (e.clientX / window.innerWidth) * 2 - 1;
          target.y = -((e.clientY / window.innerHeight) * 2 - 1);
        },
        { passive: true }
      );

      window.addEventListener("resize", debounce(resize, 150));
      document.addEventListener("visibilitychange", syncLoop);

      if ("IntersectionObserver" in window) {
        new IntersectionObserver(([entry]) => {
          inView = entry.isIntersecting;
          syncLoop();
        }).observe(container);
      }

      resize();
      if (reduceMotion.matches) render();
      else syncLoop();
    }

    return { init };
  })();

  /* ---------------- 3D Food Objects (scroll-driven) ---------------- */
  const Food3D = (() => {
    let renderer = null;
    let scene = null;
    let camera = null;
    let foods = [];
    let clock = null;
    let rafId = 0;
    let running = false;
    let canvas = null;

    // Food definitions: each has a build function and scroll trigger config
    const foodDefs = [
      {
        name: "burger",
        section: "#menu",
        build: () => buildBurger(),
        startPos: { x: -2.5, y: -0.5, z: -2 },
        endPos: { x: 2.5, y: 0.8, z: -2 },
        startRot: { x: 0.2, y: 0, z: 0.1 },
        endRot: { x: -0.2, y: Math.PI * 1.5, z: -0.1 },
        startScale: 1,
        endScale: 1.15,
      },
      {
        name: "pizza",
        section: "#pricing",
        build: () => buildPizzaSlice(),
        startPos: { x: 2.8, y: 0.5, z: -2.5 },
        endPos: { x: -2.8, y: -0.3, z: -2.5 },
        startRot: { x: -0.3, y: Math.PI * 0.25, z: 0 },
        endRot: { x: 0.3, y: Math.PI * 1.75, z: 0 },
        startScale: 1,
        endScale: 1.1,
      },
      {
        name: "momo",
        section: "#faq",
        build: () => buildMomo(),
        startPos: { x: -2.2, y: -0.8, z: -1.8 },
        endPos: { x: 2.2, y: 0.6, z: -1.8 },
        startRot: { x: 0.1, y: Math.PI * 0.5, z: -0.1 },
        endRot: { x: -0.1, y: Math.PI * 2, z: 0.1 },
        startScale: 1,
        endScale: 1.2,
      },
      {
        name: "chilli",
        section: "#gallery",
        build: () => buildChilli(),
        startPos: { x: 3, y: -1, z: -3 },
        endPos: { x: -3, y: 0.8, z: -3 },
        startRot: { x: 0, y: 0, z: 0.3 },
        endRot: { x: 0, y: Math.PI * 2, z: -0.3 },
        startScale: 0.9,
        endScale: 1.1,
      },
    ];

    function buildBurger() {
      const group = new THREE.Group();
      const bunMat = new THREE.MeshLambertMaterial({ color: 0xf5d9b8 });
      const pattyMat = new THREE.MeshLambertMaterial({ color: 0xc27a3c });
      const cheeseMat = new THREE.MeshLambertMaterial({ color: 0xe8a87c });
      const sesameMat = new THREE.MeshLambertMaterial({ color: 0x2a1b14, transparent: true, opacity: 0.4 });
      const lettuceMat = new THREE.MeshLambertMaterial({ color: 0x2f7d5b });

      // Bottom bun
      const bottomBun = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.6, 0.25, 16), bunMat);
      bottomBun.position.y = -0.55;
      group.add(bottomBun);

      // Lettuce
      const lettuce = new THREE.Mesh(new THREE.TorusGeometry(0.58, 0.04, 8, 16), lettuceMat);
      lettuce.position.y = -0.38;
      lettuce.rotation.x = -Math.PI / 2;
      group.add(lettuce);

      // Patty
      const patty = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.52, 0.2, 16), pattyMat);
      patty.position.y = -0.25;
      group.add(patty);

      // Cheese (melted look)
      const cheese = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.45, 0.08, 16), cheeseMat);
      cheese.position.y = -0.1;
      group.add(cheese);

      // Top bun
      const topBun = new THREE.Mesh(new THREE.CylinderGeometry(0.52, 0.55, 0.28, 16), bunMat);
      topBun.position.y = 0.15;
      group.add(topBun);

      // Sesame seeds
      for (let i = 0; i < 8; i++) {
        const angle = (i / 8) * Math.PI * 2;
        const r = 0.35 + Math.random() * 0.1;
        const seed = new THREE.Mesh(new THREE.SphereGeometry(0.025, 6, 6), sesameMat);
        seed.position.set(Math.cos(angle) * r, 0.28, Math.sin(angle) * r);
        group.add(seed);
      }

      return group;
    }

    function buildPizzaSlice() {
      const group = new THREE.Group();
      const crustMat = new THREE.MeshLambertMaterial({ color: 0xf5e6c8 });
      const sauceMat = new THREE.MeshLambertMaterial({ color: 0xe4572e });
      const cheeseMat = new THREE.MeshLambertMaterial({ color: 0xf2a541 });
      const pepperoniMat = new THREE.MeshLambertMaterial({ color: 0xc2410c });

      // Crust (triangular prism - using a wedge shape via extrusion)
      const shape = new THREE.Shape();
      shape.moveTo(0, 0);
      shape.lineTo(1, 0);
      shape.lineTo(0, 1);
      shape.closePath();
      const extrudeSettings = { depth: 0.15, bevelEnabled: false };
      const crustGeom = new THREE.ExtrudeGeometry(shape, extrudeSettings);
      const crust = new THREE.Mesh(crustGeom, crustMat);
      crust.position.set(-0.5, -0.5, -0.075);
      group.add(crust);

      // Sauce layer
      const sauceGeom = new THREE.ExtrudeGeometry(shape, { depth: 0.04, bevelEnabled: false });
      const sauce = new THREE.Mesh(sauceGeom, sauceMat);
      sauce.position.set(-0.5, -0.5, -0.035);
      group.add(sauce);

      // Cheese dots
      for (let i = 0; i < 12; i++) {
        const x = 0.1 + Math.random() * 0.7;
        const y = 0.1 + Math.random() * 0.7;
        if (x + y < 0.85) {
          const dot = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.03, 8), cheeseMat);
          dot.position.set(x - 0.5, y - 0.5, 0);
          group.add(dot);
        }
      }

      // Pepperoni
      for (let i = 0; i < 4; i++) {
        const x = 0.2 + Math.random() * 0.5;
        const y = 0.2 + Math.random() * 0.5;
        if (x + y < 0.85) {
          const pep = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.02, 8), pepperoniMat);
          pep.position.set(x - 0.5, y - 0.5, 0.05);
          group.add(pep);
        }
      }

      // Center group
      group.position.set(0.3, 0.3, 0);
      return group;
    }

    function buildMomo() {
      const group = new THREE.Group();
      const doughMat = new THREE.MeshLambertMaterial({ color: 0xf0e8dc });
      const pleatMat = new THREE.MeshLambertMaterial({ color: 0xd4c8b8 });

      // Main body (half sphere)
      const body = new THREE.Mesh(new THREE.SphereGeometry(0.45, 16, 16, 0, Math.PI * 2, 0, Math.PI / 2), doughMat);
      body.scale.set(1, 0.85, 1);
      body.position.y = -0.1;
      group.add(body);

      // Pleat ridges
      for (let i = 0; i < 7; i++) {
        const angle = (i / 7) * Math.PI * 2;
        const ridge = new THREE.Mesh(new THREE.TorusGeometry(0.45, 0.025, 6, 12, Math.PI), pleatMat);
        ridge.position.y = -0.1;
        ridge.rotation.x = Math.PI / 2;
        ridge.rotation.z = angle;
        group.add(ridge);
      }

      // Top pleat center
      const top = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), doughMat);
      top.position.y = 0.25;
      group.add(top);

      return group;
    }

    function buildChilli() {
      const group = new THREE.Group();
      const chilliMat = new THREE.MeshLambertMaterial({ color: 0xe4572e });
      const stemMat = new THREE.MeshLambertMaterial({ color: 0x2f7d5b });

      // Main chilli body (curved)
      const curve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(0, -0.6, 0),
        new THREE.Vector3(0.05, -0.3, 0),
        new THREE.Vector3(0.08, 0, 0),
        new THREE.Vector3(0.05, 0.3, 0),
        new THREE.Vector3(0, 0.5, 0),
      ]);
      const tubeGeom = new THREE.TubeGeometry(curve, 20, 0.06, 8, false);
      const chilli = new THREE.Mesh(tubeGeom, chilliMat);
      group.add(chilli);

      // Stem
      const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.015, 0.15, 6), stemMat);
      stem.position.set(0, 0.55, 0);
      group.add(stem);

      return group;
    }

    function init() {
      canvas = $("#food-canvas");
      if (!canvas || typeof window.THREE === "undefined" || reduceMotion.matches) {
        if (canvas) canvas.style.display = "none";
        return;
      }

      try {
        renderer = new THREE.WebGLRenderer({
          canvas: canvas,
          antialias: true,
          alpha: true,
          powerPreference: "high-performance",
        });
      } catch (_) {
        canvas.style.display = "none";
        return;
      }

      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
      renderer.setSize(window.innerWidth, window.innerHeight, false);
      canvas.setAttribute("aria-hidden", "true");

      scene = new THREE.Scene();
      camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 100);
      camera.position.set(0, 0, 5);
      clock = new THREE.Clock();

      // Lights
      const ambient = new THREE.AmbientLight(0xffffff, 0.7);
      scene.add(ambient);

      const dirLight = new THREE.DirectionalLight(0xfff4ea, 1.2);
      dirLight.position.set(3, 5, 4);
      scene.add(dirLight);

      const dirLight2 = new THREE.DirectionalLight(0xf2a541, 0.5);
      dirLight2.position.set(-3, 2, -3);
      scene.add(dirLight2);

      // Build food objects
      foodDefs.forEach((def) => {
        const mesh = def.build();
        mesh.position.set(def.startPos.x, def.startPos.y, def.startPos.z);
        mesh.rotation.set(def.startRot.x, def.startRot.y, def.startRot.z);
        mesh.scale.setScalar(def.startScale);
        scene.add(mesh);

        foods.push({
          mesh,
          def,
          // ScrollTrigger will update progress
          progress: 0,
        });
      });

      // Set up ScrollTrigger for each food
      if (hasGSAP && hasScrollTrigger) {
        foods.forEach((food) => {
          const { mesh, def } = food;
          ScrollTrigger.create({
            trigger: def.section,
            start: "top bottom",
            end: "bottom top",
            scrub: 0.8,
            onUpdate: (st) => {
              const p = st.progress;
              food.progress = p;

              // Interpolate position
              mesh.position.x = lerp(def.startPos.x, def.endPos.x, p);
              mesh.position.y = lerp(def.startPos.y, def.endPos.y, p);
              mesh.position.z = lerp(def.startPos.z, def.endPos.z, p);

              // Interpolate rotation
              mesh.rotation.x = lerp(def.startRot.x, def.endRot.x, p);
              mesh.rotation.y = lerp(def.startRot.y, def.endRot.y, p);
              mesh.rotation.z = lerp(def.startRot.z, def.endRot.z, p);

              // Interpolate scale
              const s = lerp(def.startScale, def.endScale, p);
              mesh.scale.setScalar(s);
            },
          });
        });
      }

      // Resize handler
      const resize = debounce(() => {
        if (!renderer) return;
        renderer.setSize(window.innerWidth, window.innerHeight, false);
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
      }, 150);
      window.addEventListener("resize", resize);

      // Visibility change
      document.addEventListener("visibilitychange", syncLoop);

      // Start render loop
      syncLoop();
    }

    function step(dt) {
      // Subtle idle rotation for all foods
      foods.forEach((food) => {
        if (food.progress < 1 && food.progress > 0) return; // Let ScrollTrigger handle during active scroll
        food.mesh.rotation.y += dt * 0.15;
        food.mesh.rotation.x += dt * 0.05;
      });
    }

    function render() {
      if (renderer && scene && camera) {
        renderer.render(scene, camera);
      }
    }

    function tick() {
      if (!running) return;
      rafId = requestAnimationFrame(tick);
      const dt = Math.min(clock.getDelta(), 0.05);
      step(dt);
      render();
    }

    function shouldRun() {
      return !document.hidden && !reduceMotion.matches;
    }

    function syncLoop() {
      if (!renderer) return;
      if (shouldRun()) {
        if (!running) {
          running = true;
          clock.getDelta();
          rafId = requestAnimationFrame(tick);
        }
      } else if (running) {
        running = false;
        cancelAnimationFrame(rafId);
      }
    }

    return { init };
  })();

  /* ---------------- Custom cursor (desktop only) ---------------- */
  function initCursor() {
    if (!finePointer.matches || reduceMotion.matches) return;
    const dot = $(".cursor-dot");
    const ring = $(".cursor-ring");
    if (!dot || !ring) return;

    document.documentElement.classList.add("has-custom-cursor");

    const pos = { x: -100, y: -100 };
    const ringPos = { x: -100, y: -100 };
    const hoverSel = "a, button, input, [data-magnetic], .bento-card";

    window.addEventListener("pointermove", (e) => {
      pos.x = e.clientX;
      pos.y = e.clientY;
    }, { passive: true });

    document.addEventListener("pointerover", (e) => {
      if (e.target.closest(hoverSel)) ring.classList.add("is-hover");
    });
    document.addEventListener("pointerout", (e) => {
      if (e.target.closest(hoverSel)) ring.classList.remove("is-hover");
    });

    const loop = () => {
      ringPos.x = lerp(ringPos.x, pos.x, 0.2);
      ringPos.y = lerp(ringPos.y, pos.y, 0.2);

      dot.style.transform = `translate3d(${pos.x}px, ${pos.y}px, 0)`;
      ring.style.transform = `translate3d(${ringPos.x}px, ${ringPos.y}px, 0)`;
      requestAnimationFrame(loop);
    };
    loop();
  }

  /* ---------------- Magnetic buttons ---------------- */
  function initMagnetic() {
    if (!finePointer.matches || reduceMotion.matches) return;
    $$("[data-magnetic]").forEach((el) => {
      el.addEventListener("pointermove", (e) => {
        const r = el.getBoundingClientRect();
        const x = clamp((e.clientX - (r.left + r.width / 2)) * 0.25, -8, 8);
        const y = clamp((e.clientY - (r.top + r.height / 2)) * 0.25, -8, 8);
        el.style.transform = `translate3d(${x}px, ${y}px, 0)`;
      });
      el.addEventListener("pointerleave", () => {
        el.style.transform = "";
      });
    });
  }

  /* ---------------- Bento spotlight ---------------- */
  function initSpotlight() {
    $$(".bento-card").forEach((card) => {
      card.addEventListener("pointermove", (e) => {
        const r = card.getBoundingClientRect();
        card.style.setProperty("--mx", `${e.clientX - r.left}px`);
        card.style.setProperty("--my", `${e.clientY - r.top}px`);
      });
    });
  }

  /* ---------------- Scroll progress + header state ---------------- */
  function initProgress() {
    const bar = $(".scroll-progress");
    const header = $(".site-header");
    const update = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      const p = max > 0 ? clamp(window.scrollY / max, 0, 1) : 0;
      if (bar) bar.style.transform = `scaleX(${p})`;
      if (header) header.classList.toggle("is-scrolled", window.scrollY > 24);
    };
    window.addEventListener("scroll", update, { passive: true });
    update();
  }

  /* ---------------- GSAP scroll animations ---------------- */
  function initReveals() {
    if (!hasGSAP || !hasScrollTrigger || reduceMotion.matches) return;

    $$("[data-reveal]").forEach((el) => {
      gsap.from(el, {
        y: 50,
        opacity: 0,
        duration: 0.9,
        ease: "power3.out",
        scrollTrigger: { trigger: el, start: "top 88%" },
      });
    });

    ScrollTrigger.batch(".bento-card", {
      start: "top 88%",
      onEnter: (batch) =>
        gsap.from(batch, { y: 60, opacity: 0, duration: 0.8, stagger: 0.08, ease: "power3.out" }),
    });
  }

  function initCounters() {
    $$("[data-count]").forEach((el) => {
      const to = parseFloat(el.dataset.to || "0");
      const decimals = parseInt(el.dataset.decimals || "0", 10);
      const suffix = el.dataset.suffix || "";
      const fmt = (v) => v.toFixed(decimals) + suffix;

      if (!hasGSAP || !hasScrollTrigger || reduceMotion.matches) {
        el.textContent = fmt(to);
        return;
      }

      const obj = { v: 0 };
      el.textContent = fmt(0);
      ScrollTrigger.create({
        trigger: el,
        start: "top 92%",
        once: true,
        onEnter: () =>
          gsap.to(obj, {
            v: to,
            duration: 1.8,
            ease: "power2.out",
            onUpdate: () => {
              el.textContent = fmt(obj.v);
            },
          }),
      });
    });
  }

  function initHowPin() {
    if (!hasGSAP || !hasScrollTrigger) return;
    const section = $("#how");
    const track = $(".how-track");
    const bar = $(".how-progress span");
    if (!section || !track) return;

    const mm = gsap.matchMedia();

    mm.add("(min-width: 1024px) and (prefers-reduced-motion: no-preference)", () => {
      const distance = () => Math.max(0, track.scrollWidth - window.innerWidth + 48);

      gsap.to(track, {
        x: () => -distance(),
        ease: "none",
        scrollTrigger: {
          trigger: section,
          start: "top top",
          end: () => "+=" + distance(),
          pin: true,
          scrub: 0.6,
          invalidateOnRefresh: true,
        },
      });

      if (bar) {
        gsap.to(bar, {
          scaleX: 1,
          ease: "none",
          scrollTrigger: {
            trigger: section,
            start: "top top",
            end: () => "+=" + distance(),
            scrub: 0.6,
          },
        });
      }
    });

    mm.add("(max-width: 1023px), (prefers-reduced-motion: reduce)", () => {
      if (bar) gsap.set(bar, { scaleX: 1 });
    });
  }

  /* ---------------- Image error handling (gallery) ---------------- */
  function initImageErrorHandler() {
    // Delegated error handler for gallery images
    document.addEventListener("error", (e) => {
      const img = e.target;
      if (!(img instanceof HTMLImageElement)) return;
      if (!img.closest(".gallery-item")) return;

      // Replace with warm placeholder
      const figure = img.closest(".gallery-item");
      if (!figure) return;

      // Create placeholder SVG
      const placeholder = document.createElement("div");
      placeholder.className = "img-placeholder";
      placeholder.innerHTML = `
        <svg viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg" width="80" height="80" aria-hidden="true">
          <rect width="120" height="120" rx="24" fill="url(#grad)"/>
          <defs>
            <linearGradient id="grad" x1="0" y1="0" x2="120" y2="120" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stop-color="#fff4ea"/>
              <stop offset="100%" stop-color="#ffe8d0"/>
            </linearGradient>
          </defs>
          <circle cx="60" cy="48" r="18" fill="#f2a541" fill-opacity="0.3"/>
          <path d="M60 30 Q50 38 60 42 Q70 38 60 30" fill="#e4572e" fill-opacity="0.4"/>
        </svg>
      `;
      placeholder.style.cssText = `
        position: absolute;
        inset: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, #fff4ea 0%, #ffe8d0 100%);
        z-index: 1;
      `;
      figure.style.position = "relative";
      figure.appendChild(placeholder);
      img.style.display = "none";
    }, true); // Use capture phase for error events
  }

  /* ---------------- Command palette (Ctrl/Cmd + K) ---------------- */
  function initPalette() {
    const pal = $("#palette");
    const input = $("#palette-input");
    const list = $("#palette-list");
    const openBtn = $("#palette-open");
    if (!pal || !input || !list) return;

    const actions = [
      { label: "Go to Menu", run: () => scrollToTarget($("#menu")) },
      { label: "Go to How to order", run: () => scrollToTarget($("#how")) },
      { label: "Go to Combos", run: () => scrollToTarget($("#pricing")) },
      { label: "Go to FAQ", run: () => scrollToTarget($("#faq")) },
      { label: "Order now", run: () => scrollToTarget($("#order")) },
      { label: "Back to top", run: () => scrollToTarget($("#top")) },
    ];

    let items = [];
    let active = 0;
    let lastFocus = null;

    const setActive = (i) => {
      active = i;
      $$("li", list).forEach((li, idx) => li.setAttribute("aria-selected", String(idx === i)));
    };

    const render = (query) => {
      const q = query.trim().toLowerCase();
      items = actions.filter((a) => a.label.toLowerCase().includes(q));
      list.innerHTML = "";

      if (!items.length) {
        const empty = document.createElement("li");
        empty.className = "palette-empty";
        empty.textContent = "No results";
        list.appendChild(empty);
        active = -1;
        return;
      }

      items.forEach((item) => {
        const li = document.createElement("li");
        li.setAttribute("role", "option");
        li.textContent = item.label;
        list.appendChild(li);
      });
      setActive(0);
    };

    const open = () => {
      lastFocus = document.activeElement;
      pal.hidden = false;
      document.body.classList.add("palette-open");
      input.value = "";
      render("");
      requestAnimationFrame(() => input.focus());
    };

    const close = () => {
      if (pal.hidden) return;
      pal.hidden = true;
      document.body.classList.remove("palette-open");
      if (lastFocus && typeof lastFocus.focus === "function") lastFocus.focus();
    };

    const run = (i) => {
      const item = items[i];
      if (!item) return;
      close();
      item.run();
    };

    input.addEventListener("input", () => render(input.value));

    input.addEventListener("keydown", (e) => {
      if (e.key === "ArrowDown") {
        e.preventDefault();
        if (items.length) setActive(Math.min(active + 1, items.length - 1));
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        if (items.length) setActive(Math.max(active - 1, 0));
      } else if (e.key === "Enter") {
        e.preventDefault();
        run(active);
      } else if (e.key === "Tab") {
        e.preventDefault(); // focus trap: keep focus inside the palette
      } else if (e.key === "Escape") {
        e.preventDefault();
        close();
      }
    });

    list.addEventListener("click", (e) => {
      const li = e.target.closest("li[role='option']");
      if (!li) return;
      run(Array.from(list.children).indexOf(li));
    });

    pal.addEventListener("click", (e) => {
      if (e.target === pal) close();
    });

    document.addEventListener("keydown", (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        if (pal.hidden) open();
        else close();
      } else if (e.key === "Escape" && !pal.hidden) {
        close();
      }
    });

    if (openBtn) openBtn.addEventListener("click", open);
  }

  /* ---------------- FAQ accordion ---------------- */
  function initFaq() {
    $$(".faq-q").forEach((btn) => {
      btn.addEventListener("click", () => {
        const expanded = btn.getAttribute("aria-expanded") === "true";
        btn.setAttribute("aria-expanded", String(!expanded));
        btn.parentElement.classList.toggle("is-open", !expanded);
      });
    });
  }

  /* ---------------- Order form ---------------- */
  function initForm() {
    const form = $("#subscribe");
    if (!form) return;

    const input = $("#phone");
    const error = $("#phone-error");
    const success = $("#subscribe-success");
    const submit = form.querySelector("button[type='submit']");
    const normalize = (value) => value.replace(/[\s-]/g, "");
    const isValid = (value) => /^[6-9]\d{9}$/.test(normalize(value));

    input.addEventListener("input", () => {
      if (error.textContent) {
        error.textContent = "";
        input.removeAttribute("aria-invalid");
      }
    });

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const value = normalize(input.value.trim());

      if (!isValid(value)) {
        error.textContent = "Enter a valid 10-digit mobile number.";
        input.setAttribute("aria-invalid", "true");
        input.focus();
        return;
      }

      // Demo mode: nothing is sent anywhere.
      // To go live, POST `value` to CONFIG.formEndpoint (WhatsApp API, Google Sheet, Formspree or your backend).
      if (submit) submit.disabled = true;
      form.hidden = true;
      success.hidden = false;
      success.focus();
    });
  }

  /* ---------------- Mobile menu ---------------- */
  function openMenu() {
    if (!menuEl || !menuBtn) return;
    menuEl.hidden = false;
    menuBtn.setAttribute("aria-expanded", "true");
    menuBtn.setAttribute("aria-label", "Close menu");
    document.body.classList.add("menu-open");
    if (lenis) lenis.stop();
    if (hasGSAP && !reduceMotion.matches) {
      gsap.fromTo(
        $$("li", menuEl),
        { y: 24, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.5, stagger: 0.06, ease: "power3.out" }
      );
    }
  }

  function closeMenu() {
    if (!menuEl || !menuBtn || menuEl.hidden) return;
    menuEl.hidden = true;
    menuBtn.setAttribute("aria-expanded", "false");
    menuBtn.setAttribute("aria-label", "Open menu");
    document.body.classList.remove("menu-open");
    if (lenis) lenis.start();
  }

  function initMenu() {
    menuBtn = $(".menu-toggle");
    menuEl = $("#mobile-menu");
    if (!menuBtn || !menuEl) return;
    menuBtn.addEventListener("click", () => {
      if (menuEl.hidden) openMenu();
      else closeMenu();
    });
    window.matchMedia("(min-width: 1024px)").addEventListener("change", (e) => {
      if (e.matches) closeMenu();
    });
  }

  /* ---------------- Misc ---------------- */
  function setYear() {
    const el = $("#year");
    if (el) el.textContent = String(new Date().getFullYear());
  }

  function refreshOnLoad() {
    if (!hasScrollTrigger) return;
    window.addEventListener("load", () => ScrollTrigger.refresh());
  }

  /* ---------------- Init ---------------- */
  function init() {
    if (hasGSAP && hasScrollTrigger) gsap.registerPlugin(ScrollTrigger);

    initSmoothScroll();
    initAnchors();
    initMenu();
    initProgress();
    initSpotlight();
    initFaq();
    initPalette();
    initForm();
    initCounters();
    initCursor();
    initMagnetic();
    initImageErrorHandler();
    setYear();
    refreshOnLoad();

    Scene.init($("#scene"));
    Food3D.init();

    splitHeroWords();
    playIntro(() => {
      animateHero();
      initReveals();
      initHowPin();
      if (hasScrollTrigger) ScrollTrigger.refresh();
    });
  }

  window.MOMO = { config: CONFIG };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
