# Brother Bite Landing Page

A static landing page built with HTML, CSS and vanilla JavaScript.
Three.js, GSAP and Lenis load from a CDN, so there is no build step and no `npm install`.

## Folder structure

```
brother-bite-site/
├── index.html      Page structure and menu content
├── styles.css      All styling (design tokens in :root)
├── script.js       Behaviour (3D scenes, animations, palette, form)
├── assets/
│   ├── favicon.svg
│   └── photos/
│       ├── photo-1.jpg
│       ├── photo-2.jpg
│       ├── photo-3.jpg
│       └── photo-4.jpg
└── README.md
```

## Run locally

Double-click `index.html`, or drag it into a modern browser. An internet connection is needed for the CDN libraries.

## Deploy (Netlify Drop)

1. Open https://app.netlify.com/drop
2. Drag the whole `brother-bite-site` folder onto the page.
3. Share the link Netlify gives you.

## Change colours

Edit the variables at the top of `styles.css` under `:root`:

- `--bg`: page background (cream)
- `--accent`, `--accent-2`: tomato and honey accents
- `--sage`: success and check marks
- `--espresso`: dark card used for the featured combo
- `--font-display`: heading font

The 3D particle colours are set in `script.js` inside `CONFIG` (`colorA`, `colorB`).
The 3D food object colours are defined in the `Food3D` module in `script.js`.

## Change menu and copy

Everything lives in `index.html`:
- Menu items and prices: four `.bento-card` blocks under "Our menu"
- Combos: `.plan` articles under "Combos"
- FAQ: `.faq-item` blocks under "FAQ"
- Stats: `.stat` blocks in the hero and `.metric` blocks in "Key numbers"
- Gallery captions: `figcaption` elements in the "Fresh from the stall" section

## Replace gallery photos

Place your own photos in `assets/photos/`:
- `photo-1.jpg` — Smash burger (used as featured, spans 2 columns on desktop)
- `photo-2.jpg` — Stone-baked pizza
- `photo-3.jpg` — Steamed momos
- `photo-4.jpg` — Our counter

Recommended: ~1200px wide, under 300 KB each, JPG format. If a photo is missing, a warm placeholder appears automatically.

## Connect the order form

1. In `script.js`, set `CONFIG.formEndpoint` to your URL.
2. In `initForm`, replace the demo block with a POST, for example:

```js
await fetch(CONFIG.formEndpoint, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ phone: value }),
});
```

WhatsApp Business API, Google Apps Script, Formspree or your own backend all work.

## Customise 3D food animations

The scroll-driven 3D food objects are in `script.js` in the `Food3D` module:
- Four objects: burger (menu), pizza slice (combos), momo (FAQ), chilli (gallery)
- Each tied to a section via `section` selector in `foodDefs`
- Adjust `startPos`/`endPos`, `startRot`/`endRot`, `startScale`/`endScale` per object
- Scrub value (0.8) controls how tightly animation follows scroll

## Performance and accessibility

- Particle count is in `CONFIG.particles`. Low-end devices use the lower count automatically.
- Both 3D loops pause when their canvas is off-screen or the tab is hidden.
- Device pixel ratio capped at 1.5 for performance.
- Reduced-motion users get static scenes and no scroll animations.
- Keyboard navigation, focus outlines (2px tomato, 3px offset) and ARIA labels included.
- Images use `loading="lazy"` and `decoding="async"`.
- Semantic HTML with proper heading hierarchy.
